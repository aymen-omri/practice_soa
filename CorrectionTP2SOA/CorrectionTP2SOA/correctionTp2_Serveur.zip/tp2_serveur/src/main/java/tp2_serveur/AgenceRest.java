package tp2_serveur;

import java.util.ArrayList;

import jakarta.ws.rs.Consumes;
import jakarta.ws.rs.DELETE;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.PUT;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.PathParam;
import jakarta.ws.rs.Produces;
import jakarta.ws.rs.QueryParam;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

@Path("/agence")
public class AgenceRest {

	//Attribut(s) de la classe
static ArrayList<Agence> agenceList;
	
//Constructeur vide
public AgenceRest()
	{
		agenceList = new ArrayList<Agence>();
		ArrayList<Voyage> voyageList1 = new ArrayList<Voyage>();
		voyageList1.add(new Voyage(1,"Tunisie","Allemagne","12-12-2022"));
		voyageList1.add(new Voyage(2,"Tunisie","France","10-08-2022"));
		agenceList.add(new Agence(1,"Tunisia Travels", voyageList1));
		ArrayList<Voyage> voyageList2 = new ArrayList<Voyage>();
		voyageList2.add(new Voyage(1,"France","Allemagne","13-11-2022"));
		voyageList2.add(new Voyage(2,"Tunisie","Turkie","22-05-2022"));
		agenceList.add(new Agence(2,"Go and Trip", voyageList2));
	}


	@Path("/all")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAll()
	{
		if(agenceList.size()==0)
			return Response.status(Status.NO_CONTENT).entity(agenceList).build();
		else
			return Response.status(Status.OK).entity(agenceList).build();
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAgenceById(@QueryParam("id") int id)
	{
		try
		{
			for (int i=0; i<agenceList.size() ; i++)
			{
				if (agenceList.get(i).getIdAgence()==id)
					return Response.status(Status.OK).entity(agenceList.get(i)).build();
			}
			return Response.status(Status.NO_CONTENT).entity("Id "+ id +" inexistant").build();
		}
		catch(Exception e)
		{
			return Response.serverError().entity("Echec "+id).build();
		}
	}
	
	@Path("/{ville}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAgenceByVilleDepartVoyage(@PathParam("ville") String villeDepart)
	{
		ArrayList<Agence> list = new ArrayList<Agence>();
		boolean found = false;
		try
		{
			for (int i=0; i<agenceList.size() ; i++)
			{
				found = false;
				int j= 0;
				while(j<agenceList.get(i).getVoyageList().size()&&!found)
				{
					if (agenceList.get(i).getVoyageList().get(j).getVilleDepart().equals(villeDepart)&&!found)
						list.add(agenceList.get(i));
					j++;
				}
			}
			return Response.status(Status.OK).entity(list).build();
			/*Si on veut distinguer entre le cas de agenceList vide (code 204) ou non (code 200)
			 * alors il est possible de faire un test sur la taille de la agenceList à retourner
			 */
			//if(list.size()==0)
			//	return Response.status(Status.NO_CONTENT).entity(list).build();
			//else
			//	return Response.status(Status.OK).entity(list).build();
		}
		catch(Exception e)
		{
			return Response.serverError().entity("Echec ").build();
		}
	}
	
	
	@Path("/{id}")
	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	public Response deleteAgence(@PathParam("id") int id)
	{
		try
		{
			for (int i=0; i<agenceList.size() ; i++)
			{
				if (agenceList.get(i).getIdAgence()==id)
				{
					agenceList.remove(i);
					return Response.status(Status.OK).entity(agenceList).build();
				}
			}
			//avec le test niveau postman, le message ne sera pas affichée 
			//même si l'objet Entity est initialisé
			//Rappel : le code 204 n'affiche pas l'objet Entity
			//Pour afficher le message alors il faut remplacer le code 204 par 200
			//return Response.status(Status.OK).entity("Id "+ id +" inexistant").build();
			return Response.status(Status.OK).entity("Id d'agence "+ id +" inexistant").build();
		}
		catch(Exception e)
		{
			return Response.serverError().entity("Echec d'execution").build();
		}	
	}
	
	
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Response addEtudiant(Agence agence)
	{
		try
		{
			for (int i=0; i<agenceList.size() ; i++)
			{
				if (agenceList.get(i).getIdAgence()==agence.getIdAgence())
				{
					return Response.status(Status.OK).entity("Id d'agence "+ agence.getIdAgence() +" existant").build();
				}
			}
			agenceList.add(agence);
			return Response.status(Status.CREATED).entity(agenceList).build();
		}
		catch(Exception e)
		{
			return Response.serverError().entity("Echec d'execution").build();
		}
	}
	
	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response updateAgence(Agence agence)
	{
		try
		{
			for (int i=0; i<agenceList.size() ; i++)
			{
				if (agenceList.get(i).getIdAgence()==agence.getIdAgence())
				{
					agenceList.get(i).setVoyageList(agence.getVoyageList());
					agenceList.get(i).setNomAgence(agence.getNomAgence());;
					return Response.status(Status.OK).entity(agenceList).build();
				}
			}
			return Response.status(Status.OK).entity("Id de agence "+ agence.getIdAgence() +" inexistant").build();
		}
		catch(Exception e)
		{
			return Response.serverError().entity("Echec de mise à jour de l'agence ayant l'id "+agence.getIdAgence()).build();
		}
	}
	
}
