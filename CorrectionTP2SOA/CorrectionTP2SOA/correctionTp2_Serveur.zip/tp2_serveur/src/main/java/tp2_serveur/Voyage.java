package tp2_serveur;

public class Voyage {
	
	private int idVoyage;
	private String villeDepart;
	private String villeArrivee;
	private String  dateVoyage;
	
	public Voyage() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Voyage(int idVoyage, String villeDepart, String villeArrivee, String dateVoyage) {
		super();
		this.idVoyage = idVoyage;
		this.villeDepart = villeDepart;
		this.villeArrivee = villeArrivee;
		this.dateVoyage = dateVoyage;
	}
	public int getIdVoyage() {
		return idVoyage;
	}
	public void setIdVoyage(int idVoyage) {
		this.idVoyage = idVoyage;
	}
	public String getVilleDepart() {
		return villeDepart;
	}
	public void setVilleDepart(String villeDepart) {
		this.villeDepart = villeDepart;
	}
	public String getVilleArrivee() {
		return villeArrivee;
	}
	public void setVilleArrivee(String villeArrivee) {
		this.villeArrivee = villeArrivee;
	}
	public String getDateVoyage() {
		return dateVoyage;
	}
	public void setDateVoyage(String dateVoyage) {
		this.dateVoyage = dateVoyage;
	}

}
