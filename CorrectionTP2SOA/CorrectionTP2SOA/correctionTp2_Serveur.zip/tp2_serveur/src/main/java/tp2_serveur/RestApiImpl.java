package tp2_serveur;

import java.util.ArrayList;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.MediaType;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Response.Status;

@Path("voyage")
public class RestApiImpl {
	
	static ArrayList<Voyage> voyageList;
	
	@Path("/all")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getAll()
	{
		voyageList = new ArrayList<Voyage>();

		// la classe Voyage dispose des champs id, villeDepart, villeArrivee, dateVoyage
		voyageList.add(new Voyage(1,"Tunisie","Allemagne","12-12-2022"));
		voyageList.add(new Voyage(2,"Tunisie","France","10-08-2022"));
		voyageList.add(new Voyage(3,"Tunisie","France","10-07-2022"));
		voyageList.add(new Voyage(4,"Tunisie","Liban","20-09-2022"));
		return Response.ok().entity(voyageList).build();
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getVoyageById(@QueryParam("id") int id)
	{
		try
		{
			getAll();
			for (int i=0; i<voyageList.size() ; i++)
			{
				if (voyageList.get(i).getIdVoyage()==id)
					return Response.ok().entity(voyageList.get(i)).build();
			}
			return Response.status(Status.OK).entity("Id"+id+" inexistant").build();
		}
		catch(Exception e)
		{
			return Response.serverError().entity("Echec d'execution").build();
		}
	}
	
	@Path("/{villeD}/{villeA}")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public Response getVoyageByVilleDepart(@PathParam("villeD") String villeDepart, @PathParam("villeA") String villeArrivee)
	{
		ArrayList<Voyage> list = new ArrayList<Voyage>();
		getAll();
		try
		{
			for (int i=0; i<voyageList.size() ; i++)
			{
				if (voyageList.get(i).getVilleDepart().equals(villeDepart)&&voyageList.get(i).getVilleArrivee().equals(villeArrivee))
					list.add(voyageList.get(i));
			}
			return Response.ok().entity(list).build();
		}
		catch(Exception e)
		{
			return Response.serverError().entity("Echec d'execution").build();
		}
	}
	
	@Path("/{identifier}")
	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	public Response deleteVoyage(@PathParam("identifier") int id)
	{
		try
		{
			getAll();
			for (int i=0; i<voyageList.size() ; i++)
			{
				if (voyageList.get(i).getIdVoyage()==id)
				{
					voyageList.remove(i);
					return Response.ok().entity("Voyage supprimé").build();
				}
			}
			return Response.status(Status.OK).entity("Id de voyage "+ id +" inexistant").build();
		}
		catch(Exception e)
		{
			return Response.serverError().entity("Echec d'execution").build();
		}
	}
	
	@PUT
	@Produces(MediaType.APPLICATION_JSON)
	public Response updateVoyage(@FormParam("identifier") int id, @FormParam("villeD") String villeD, @FormParam("villeA") String villeA, @FormParam("dateVoyage") String dateVoyage)
	{
		try
		{
			getAll();
			for (int i=0; i<voyageList.size() ; i++)
			{
				if (voyageList.get(i).getIdVoyage()==id)
				{
					voyageList.get(i).setVilleDepart(villeD);
					voyageList.get(i).setVilleArrivee(villeA);
					voyageList.get(i).setDateVoyage(dateVoyage);
					return Response.ok().entity("Voyage mis à jour").build();
				}
			}
			return Response.status(Status.OK).entity("Id de voyage "+ id +" inexistant").build();
		}
		catch(Exception e)
		{
			return Response.serverError().entity("Echec d'execution").build();
		}
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	public void addVoyage(Voyage voyage)
	{
		getAll();
		voyageList.add(voyage);
	}
}