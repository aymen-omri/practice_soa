package tp2_serveur;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.core.Application;

@ApplicationPath("RestAPI")
public class RestApi extends Application {

}
