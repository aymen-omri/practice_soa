package tp2_serveur;

import java.util.ArrayList;

public class Agence {

	public Agence() {
		super();
		// TODO Auto-generated constructor stub
	}


	private int idAgence ;
	private String nomAgence ;
	private ArrayList<Voyage> voyageList;
	   
    public int getIdAgence() {
		return idAgence;
	}


	public void setIdAgence(int idAgence) {
		this.idAgence = idAgence;
	}


	public String getNomAgence() {
		return nomAgence;
	}


	public void setNomAgence(String nomAgence) {
		this.nomAgence = nomAgence;
	}


	public ArrayList<Voyage> getVoyageList() {
		return voyageList;
	}


	public void setVoyageList(ArrayList<Voyage> voyageList) {
		this.voyageList = voyageList;
	}


	public Agence (int idAgence, String nomAgence, ArrayList<Voyage> voyageList) 	{  
        this.idAgence= idAgence;
		this.nomAgence= nomAgence;
		this.voyageList= voyageList;   
   	}

 
	
    
	
	
}
